<?php   include('header.php'); ?>
 
   <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">contact Form</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">General Form</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid"> 
            <!--begin::Row-->
            <div class="row g-4">
              <!--begin::Col-->
              <div class="col-12">
                <div class="callout callout-info">
                  For detailed documentation of Form visit
                  <a
                    href="https://getbootstrap.com/docs/5.3/forms/overview/"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="callout-link"
                  >
                    Bootstrap Form
                  </a>
                </div>
              </div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-md-12">
                <!--begin::Quick Example-->
                <div class="card card-primary card-outline mb-4">
                  <!--begin::Header-->
                  <div class="card-header"><div class="card-title">Quick Example</div>
 <a href="<?php echo BASE_URL;?>/contact.php">  <button class="btn btn-primary float-right" style="float: right;"> contact List</button></a>
                </div>
                  <!--end::Header-->
                  <!--begin::Form-->


<?php 

if(!empty($_GET['id'])){
 $id = $_GET['id'];
 $sql = "SELECT * FROM contact where id='$id'";
 $result = mysqli_query($conn, $sql);
 $detail = mysqli_fetch_assoc($result);

 $name = $detail['name'];
 $email = $detail['email'];
  $subject = $detail['subject'];
  $massage = $detail['massage'];

 $form = './admin/query/save-contact.php?id='.$id;
}else{
 $name = '';
 $subject='';
 $massage='';
 

 $form = './admin/query/save-contact.php';

}


 ?>

 
             <form action="<?php echo $form; ?>" method="post" enctype="multipart/form-data">
          

                    <!--begin::Body-->
                    <div class="card-body">
                      <p class="text-danger"><?php echo @$_GET['error']?'Something went wrong please check form detail':''; ?></p>
                     
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Name *</label>
                        <input   type="text" name="name"  class="form-control" required  value="<?= $name;  ?>"     />
                        <div id="emailHelp" class="form-text">
                         <p class="text-danger"> <?php echo @$_GET['name']?'Please fill this out':''; ?></p>
                        </div>
                      </div>

                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">email </label>
                        <input   type="text" name="email"  class="form-control"   value="<?= $email ;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>
<div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">subject </label>
                      
                        <textarea name="subject"  class="form-control"><?php echo $subject; ?></textarea>
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

<div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">massage </label>
                      
                        <textarea name="massage"  class="form-control"><?php echo $massage; ?></textarea>
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                    </div>
                    <!--end::Body-->
                    <!--begin::Footer-->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <!--end::Footer-->
                  </form>
                  <!--end::Form-->
                </div>
                <!--end::Quick Example-->
                <!--begin::Input Group-->
            
                <!--end::Horizontal Form-->
              </div>
              <!--end::Col-->
              <!--begin::Col-->
          
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>





      <?php   include('footer.php'); ?>