<?php   include('header.php'); ?>
 
   <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">General Form</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">General Form</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container--> 
          <div class="container-fluid"> 
            <!--begin::Row-->
            <div class="row g-4">
              <!--begin::Col-->
              <div class="col-12">
                <div class="callout callout-info">
                  For detailed documentation of Form visit
                  <a
                    href="https://getbootstrap.com/docs/5.3/forms/overview/"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="callout-link"
                  >
                    Bootstrap Form
                  </a>
                </div>
              </div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-md-12">
                <!--begin::Quick Example-->
                <div class="card card-primary card-outline mb-4">
                  <!--begin::Header-->
                  <div class="card-header"><div class="card-title">Quick Example</div>
 <a href="<?php echo BASE_URL;?>/courses.php">  <button class="btn btn-primary float-right" style="float: right;"> Course List</button></a>
                </div>
                  <!--end::Header-->
                  <!--begin::Form-->


<?php 

if(!empty($_GET['id'])){
 $id = $_GET['id'];
 $sql = "SELECT * FROM courses where id='$id'";
 $result = mysqli_query($conn, $sql);
 $detail = mysqli_fetch_assoc($result);

 $name = $detail['name'];
 $image = $detail['image'];
 $writer = $detail['writer'];
$rating = $detail['rating'];
$outof = $detail['outof'];
$description = $detail['description'];
$slug = $detail['slug'];
 
 $form = './admin/query/save-course.php?id='.$id;

}else{
 $name = '';
 $image = '';
$writer = '';
$rating = '';
$outof = '';
 $description = '';
$slug = '';

 $form = './admin/query/save-course.php';

}


 ?>

 
             <form action="<?php echo $form; ?>" method="post" enctype="multipart/form-data">
          

                    <!--begin::Body-->
                    <div class="card-body">
                      <p class="text-danger"><?php echo @$_GET['error']?'Something went wrong please check form detail':''; ?></p>
                     
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Name *</label>
                        <input   type="text" name="name"  class="form-control" required  value="<?= $name;  ?>"     />
                        <div id="emailHelp" class="form-text">
                         <p class="text-danger"> <?php echo @$_GET['name']?'Please fill this out':''; ?></p>
                        </div>
                      </div>

                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Writer </label>
                        <input   type="text" name="writer"  class="form-control"   value="<?= $writer ;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                       <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Rating </label>
                        <input   type="text" name="rating"  class="form-control"   value="<?= $rating;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                       <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">outof </label>
                        <input   type="text" name="outof"  class="form-control"   value="<?=$outof;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">description </label>
                      
                        <textarea name="description"  class="form-control"><?php echo $description; ?></textarea>
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                      <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">slug</label>
                        <input   type="text" name="slug"  class="form-control"   value="<?= $slug;  ?>"     />
                        
                      </div>


                      <?php if (!empty($image)): ?>
                          <img src="<?php echo BASE_URL.$image; ?>" width="100" height="100">
                           <input type="hidden" name="old_image" value="<?php echo $image; ?>">
                        <?php endif ?>
                        <br>
                      <div class="input-group input-group-sm mb-2"> Image

                        <input type="file" name="image" class="form-control form-control-sm" />                       
                    
                      </div>


                    </div>
                    <!--end::Body-->
                    <!--begin::Footer-->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <!--end::Footer-->
                  </form>
                  <!--end::Form-->
                </div>
                <!--end::Quick Example-->
                <!--begin::Input Group-->
            
                <!--end::Horizontal Form-->
              </div>
              <!--end::Col-->
              <!--begin::Col-->
          
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>





      <?php   include('footer.php'); ?>