<?php   include('header.php'); ?>
 
   <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">Instructorn Form</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">General Form</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid"> 
            <!--begin::Row-->
            <div class="row g-4">
              <!--begin::Col-->
              <div class="col-12">
                <div class="callout callout-info">
                  For detailed documentation of Form visit
                  <a
                    href="https://getbootstrap.com/docs/5.3/forms/overview/"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="callout-link"
                  >
                    Bootstrap Form
                  </a>
                </div>
              </div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-md-12">
                <!--begin::Quick Example-->
                <div class="card card-primary card-outline mb-4">
                  <!--begin::Header-->
                  <div class="card-header"><div class="card-title">Quick Example</div>
 <a href="<?php echo BASE_URL;?>/instructor.php">  <button class="btn btn-primary float-right" style="float: right;"> Instructor List</button></a>
                </div>
                  <!--end::Header-->
                  <!--begin::Form-->


<?php 

if(!empty($_GET['id'])){
 $id = $_GET['id'];
 $sql = "SELECT * FROM instructor where id='$id'";
 $result = mysqli_query($conn, $sql);
 $detail = mysqli_fetch_assoc($result);
// print_r($detail);
 $name = $detail['name'];
 $course = $detail['course'];
 $logo= $detail['logo']?$detail['logo']:'';
 $image = $detail['image']?$detail['image']:'';
 $form = './admin/query/save-instructor.php?id='.$id;
}else{
 $name = '';
 $course='';
 $logo='';
 $image = '';


 $form = './admin/query/save-instructor.php';

}



$sql = "SELECT * FROM courses";
$result = $conn->query($sql);
$courseList = $result->fetch_all(MYSQLI_ASSOC);





 ?>

 
             <form action="<?php echo $form; ?>" method="post" enctype="multipart/form-data">
          

                    <!--begin::Body-->
                    <div class="card-body">
                      <p class="text-danger"><?php echo @$_GET['error']?'Something went wrong please check form detail':''; ?></p>
                     
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Name *</label>
                        <input   type="text" name="name"  class="form-control" required  value="<?= $name;  ?>"     />
                        <div id="emailHelp" class="form-text">
                         <p class="text-danger"> <?php echo @$_GET['name']?'Please fill this out':''; ?></p>
                        </div>
                      </div>

                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">course </label>
                       
                        <select class="form-control" name="course">
                          <option value="">Select</option>
                          <?php if (!empty($courseList)){foreach ($courseList as $key => $value) {?>
                       
                          <option value="<?php echo $value['id']; ?>" <?php echo $course==$value['id']?'selected':''; ?>  ><?php echo $value['name']; ?></option>

                        <?php }} ?>
                        </select>

                      </div>

                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">logo </label>
                        <input   type="text" name="logo"  class="form-control"   value="<?= $logo ;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>


                      <?php if (!empty($image)): ?>
                          <img src="<?php echo BASE_URL.$image; ?>" width="100" height="100">
                           <input type="hidden" name="old_image" value="<?php echo $image; ?>">
                        <?php endif ?>
                        <br>
                      <div class="input-group input-group-sm mb-2"> Image

                        <input type="file" name="image" class="form-control form-control-sm" />                       
                    
                      </div>


                    </div>
                    <!--end::Body-->
                    <!--begin::Footer-->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <!--end::Footer-->
                  </form>
                  <!--end::Form-->
                </div>
                <!--end::Quick Example-->
                <!--begin::Input Group-->
            
                <!--end::Horizontal Form-->
              </div>
              <!--end::Col-->
              <!--begin::Col-->
          
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>





      <?php   include('footer.php'); ?>