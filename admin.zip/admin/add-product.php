<?php   include('header.php'); 
require('db.php');
?>
 
   <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">product</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">General Form</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid"> 
            <!--begin::Row-->
            <div class="row g-4">
              <!--begin::Col-->
              <div class="col-12">
               success
              </div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-md-12">
                <!--begin::Quick Example-->
                <div class="card card-primary card-outline mb-4">
                  <!--begin::Header-->
                  <div class="card-header"><div class="card-title">Quick Example</div>
 <a href="<?php echo BASE_URL;?>/product.php">  <button class="btn btn-primary float-right" style="float: right;"> product List</button></a>
                </div>
                  <!--end::Header-->
                  <!--begin::Form-->


<?php 

if(!empty($_GET['id'])){
 $id = $_GET['id'];
 $sql = "SELECT * FROM products where id='$id'";
 $result = mysqli_query($conn, $sql);
 $detail = mysqli_fetch_assoc($result);
 $name = $detail['name'];
  $price = $detail['price'];
   $color = $detail['color'];
 $sort_order = $detail['sort_order'];
  $create_order = $detail['create_order'];
   $special_price = $detail['special_price'];
   $price_category = $detail['price_category'];
   $size = $detail['size'];
$image = $detail['image'];




 $form = './admin/query/save-product.php?id='.$id;
}else{
 $name = '';
 $price='';
 $color='';
 $status = '';
  $short_order = '';
   $create_order = '';
    $special_price = '';

   $price_category = '';
   $size = '';
$image = '';

 $form = './admin/query/save-product.php';
}


 ?>

 
             <form action="<?php echo $form; ?>" method="post" enctype="multipart/form-data">
          

                    <!--begin::Body-->
                    <div class="card-body">
                      <p class="text-danger"><?php echo @$_GET['error']?'Something went wrong':''; ?></p>
                     
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Name *</label>
                       <input   type="text" name="name"  class="form-control" required  value="<?= $name;  ?>"     />
                        <div id="emailHelp" class="form-text">
                         <p class="text-danger"> <?php echo @$_GET['name']?'Please fill this out':''; ?></p>
                        </div>

                      </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Special Price </label>
                        <input   type="text" name="special_price"  class="form-control"   value="<?=$special_price;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Price </label>
                        <input   type="text" name="price"  class="form-control"   value="<?=$price;  ?>"     />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                     <div class="mb-3">
                      
                        <label for="exampleInputEmail1" class="form-label">Image </label>
                        <?php if (!empty($image)): ?>
                          <img src="<?php echo @BASE_URL.$image; ?>" width="100" height="100">
                        <input type="hidden" name="old_image" value="<?php echo $image; ?>">

                        <?php endif ?>
                        <input   type="file" name="image"  class="form-control" />
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>
                    
                      
             <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">price category </label>
                      <select class="form-control" name="price_category">
                        <option value="">Select</option>


                 <?php  $sql = "SELECT * FROM price";
                    $result = $conn->query($sql);
                     $list = $result->fetch_all(MYSQLI_ASSOC);
                     if (!empty($list)) { 
                     foreach ($list as $key => $value){
              
               ?>

                       <option value="<?php echo $value['id']; ?>" <?php echo $price_category==$value['id']?'selected':''; ?>><?php echo $value['name']; ?></option>  
                 <?php }} ?>

                        
                      </select>    
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">color</label>
                      <select class="form-control" name="color">
                        <option value="">Select</option>


                   <?php  $sql = "SELECT * FROM color";
                    $result = $conn->query($sql);
                     $list = $result->fetch_all(MYSQLI_ASSOC);
                     if (!empty($list)) { 
                     foreach ($list as $key => $value){
              
               ?>

             <option value="<?php echo $value['id']; ?>" <?php echo $color==$value['id']?'selected':''; ?>   ><?php echo $value['name']; ?></option>            
                      <?php }} ?>

                        
                      </select>    
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>



                     

                    
                        <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Size</label>
                      <select class="form-control" name="size">
                        <option value="">Select</option>

                   <?php  $sql = "SELECT * FROM size";
                    $result = $conn->query($sql);
                     $list = $result->fetch_all(MYSQLI_ASSOC);
                     if (!empty($list)) { 
                     foreach ($list as $key => $value){
              
               ?>
                 <option value="<?php echo $value['id']; ?>" <?php echo $size==$value['id']?'selected':''; ?>   ><?php echo $value['name']; ?></option>
                     <?php }} ?>
                       
                         
                      </select>    
                        <div id="emailHelp" class="form-text">
                        
                        </div>
                      </div>

                    <!--end::Body-->
                    <!--begin::Footer-->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                    <!--end::Footer-->
                  </form>
                  <!--end::Form-->
                </div>
                <!--end::Quick Example-->
                <!--begin::Input Group-->
            
                <!--end::Horizontal Form-->
              </div>
              <!--end::Col-->
              <!--begin::Col-->
          
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>





      <?php   include('footer.php'); ?>