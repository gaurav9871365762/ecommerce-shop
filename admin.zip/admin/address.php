<?php   include('header.php');


if (!empty($_GET['delete'])) {
  $id = $_GET['delete'];
  $sql = "DELETE FROM address WHERE id = '$id' ";
  $result = mysqli_query($conn,$sql);
  if($result){
    // header('Location: hotel.php?success=delete');
  }
}




 ?>
 
   <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">All Enquiry  List</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Simple Tables</li>
                </ol>
              </div>
                          </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-md-12">
                <h4 class="text-success"><?php echo @$_GET['success']==1?'Record create successfully': (@$_GET['delete']? 'Record delete successfully!':''); ?></h4>
                <div class="card mb-4">
                  <div class="card-header"><h3 class="card-title">contact List</h3>

                
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <table class="table table-bordered">
                      
                      <thead>
                        <tr>
                          <th style="width: 10px">#</th>
                          <th>first Name</th>
                           <th>last Name</th>
                          <th>email</th>
                           <th>number</th>
                           <th>address l1</th>
                           <th>address l2</th>
                          <th>country</th>
                           <th>city</th>
                            <th>state</th>
                               <th>zip code</th>

                          <th>Action</th>
                       
                        </tr>
                      </thead>

                      <tbody>
        <?php 

        $sql = "SELECT * FROM address";
        $result = $conn->query($sql);
         $list = $result->fetch_all(MYSQLI_ASSOC);
         if (!empty($list)) { 
              foreach ($list as $key => $value) { ?>


                       <tr class="align-middle">
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $value['f_name']; ?></td>
                           <td><?php echo $value['l_name']; ?></td>
                           <td><?php echo $value['email']; ?></td>
                            <td><?php echo $value['number'];?></td>
                            <td><?php   echo $value['address_1']; ?></td>
                             <td><?php echo $value['address_2'];?></td>
                             <td><?php echo $value['country'];?></td>
                             <td><?php echo $value['city'];?></td>
                             <td><?php echo $value['state'];?></td>
                             <td><?php echo $value['zip_code']; ?></td>
                         <!-- 
                          <td> <a href="admin/add-contact.php?id=<?php echo $value['id']; ?>"> <button class="btn btn-info">Edit</button></a> &nbsp; <a href="admin/contact.php?delete=<?php echo $value['id']; ?>"> <button class="btn btn-danger">Delete</button></a></td> -->
                        </tr>

                      <?php } }  ?>
                      
                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer clearfix">
                    <ul class="pagination pagination-sm m-0 float-end">
                      <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                    </ul>
                  </div>
                </div>
                <!-- /.card -->
              
                <!-- /.card -->
              </div>
          
              <!-- /.col -->
            </div>  
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>





      <?php   include('footer.php'); ?>