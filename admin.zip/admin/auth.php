<?php
session_start();
require('db.php');

$username = $_POST['username'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = mysqli_query($conn,$sql);
// Execute query
 $row = mysqli_fetch_assoc($result);
// Check result
if (!empty($row)) {
    // echo "Login successful!";

        // create session
        $_SESSION['id'] = $row['id'];
        $_SESSION['name'] = $row['name'];
        $_SESSION['isValid'] = true;

      header('Location: dashboard.php');
} else {

  header('Location: index.php?error=1');
  
}


?>


?>