<?php

define('CATALOG', '/admin/dist/');
define('BASE_URL','http://localhost:8080/admin');


?>