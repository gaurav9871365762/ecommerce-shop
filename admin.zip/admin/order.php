<?php   include('header.php');




 ?>
 
   <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">All order  List</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Simple Tables</li>
                </ol>
              </div>
                          </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-md-12">
                <h4 class="text-success"><?php echo @$_GET['success']==1?'Record create successfully': (@$_GET['delete']? 'Record delete successfully!':''); ?></h4>
                <div class="card mb-4">
                  <div class="card-header"><h3 class="card-title"> all order detail</h3>

                
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                    <table class="table table-bordered">
                      
                      <thead>
                        <tr>
                          <th style="width: 10px">#</th>
                          <th>first Name</th>
                         
                          <th>email</th>
                           <th>number</th>
                           <th>address</th>
                         
                       
                             
                               <th>subtotal</th>
                                <th>discount</th>
                                 <th>shipping</th>
 <th>total </th>
                          <th>Action</th>
                       
                        </tr>
                      </thead>

                      <tbody>
        <?php 

        $sql = "SELECT ord.*,ur.name,ur.email as user_email,ur.phone as user_phone,ur.image FROM orders as ord LEFT JOIN users as ur on ord.user_id=ur.id";
        $result = $conn->query($sql);
         $list = $result->fetch_all(MYSQLI_ASSOC);
         if (!empty($list)) { 
              foreach ($list as $key => $value) { ?>


                       <tr class="align-middle">
                          <td><?php echo $key+1; ?></td>
                          <td><?php echo $value['name']; ?></td>
                      
                           <td><?php echo $value['user_email']; ?></td>
                            <td><?php echo $value['user_phone'];?></td>
                            <td><?php   echo $value['address1'].' '.$value['address2'].' '.$value['country'].' '.$value['city'].' '.$value['state'].' '.$value['zip_code']; ?></td>
                          
                
                          
                             <td><?php echo $value['subtotal']; ?></td>
                             <td><?php echo $value['discount']; ?></td>
                             <td><?php echo $value['shiping']; ?></td>
                            <td><?php echo $value['total']; ?></td>
                          <td> <a href="admin/view-order.php?id=<?php echo $value['id']; ?>"> <button class="btn btn-info">view order</button></a> &nbsp;


                        </tr>

                      <?php } }  ?>
                      
                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer clearfix">
                    <ul class="pagination pagination-sm m-0 float-end">
                      <li class="page-item"><a class="page-link" href="#">&laquo;</a></li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                    </ul>
                  </div>
                </div>
                <!-- /.card -->
              
                <!-- /.card -->
              </div>
          
              <!-- /.col -->
            </div>  
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>





      <?php   include('footer.php'); ?>