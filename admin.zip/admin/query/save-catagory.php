<?php 
session_start();
require('../db.php');

 //$starting = $_POST['name'] ?? exit("Error: 'starting' field is missing!");

$name = $_POST['name'];
if (!empty($_GET['id'])) {
  $id = $_GET['id'];
 $image = $image ? $image : ($_POST['old_image'] ?? '');

// update
  $sql = "UPDATE catagory SET name = '$name'  WHERE id = '$id' ";
}else{
  // insert
  $sql = "INSERT INTO catagory(name) VALUES ('$name')";
}

// echo $sql;exit;

 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ../catagory.php?=1');
} else {
   header('Location: ../add-catagory.php?error=1');
}


 ?>