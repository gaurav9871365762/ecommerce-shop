<?php 
session_start();
require('../db.php');

// $starting = $_POST['starting'] ?? exit("Error: 'starting' field is missing!");

$name = $_POST['name'];
$description = $_POST['description'];
$starting_price = $_POST['starting_price'];
$image = '';


// upload image

if (isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $filename = $file['name'].rand(1111,9999);
    $tmpname = $file['tmp_name'];

    // Upload folder
    $folder = "../uploads/" . $filename;

    // Move image from temp to uploads folder
    if (move_uploaded_file($tmpname, $folder)) {
       $image = '/uploads/'.$filename;
    } else {
   
    }
}

////////////

if (!empty($_GET['id'])) {
  $id = $_GET['id'];
  $image = $image?$image:$_POST['old_image'];
// update
  $sql = "UPDATE hotel SET name = '$name', description = '$description' , starting_price = '$starting_price' , image = '$image'  WHERE id = '$id' ";
}else{
  // insert
  $sql = "INSERT INTO hotel (name, description, starting_price,image) VALUES ('$name', '$description', '$starting_price','$image')";
}



 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ../hotel.php?success=1');
} else {
   header('Location: ../add-hotel.php?error=1');
}


 ?>