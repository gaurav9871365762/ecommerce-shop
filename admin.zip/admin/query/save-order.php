<?php 
session_start();
require('../db.php');

// $starting = $_POST['starting'] ?? exit("Error: 'starting' field is missing!");

 $f_name = $_POST['f_name'];
    $l_name = $_POST['l_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address_1 = $_POST['address1'];
    $address_2 = $_POST['address2'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $zip_code = $_POST['zip_code'];
     $total = $_POST['total'];
      $subtotal = $_POST['subtotal'];
       $discount = $_POST['discount'];
        $shipping = $_POST['shipping'];

// upload image


////////////

if (!empty($_GET['id'])) {
  $id = $_GET['id'];
 
// update
  $sql = "UPDATE hotel SET name = '$name', description = '$description' , starting_price = '$starting_price' , image = '$image'  WHERE id = '$id' ";
}else{
  // insert
 $sql = "INSERT INTO orders(fname,lname,email,phone,address1,address2,country,city,state,zip_code,payment) VALUES ('$fname','$lname', '$email','$phone','$address1','$address2','$country','$city','$state','$zip_code','$payment')";
}



 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ../order.php?success=1');
} else {
   header('Location: ../order.php?error=1');
}


 ?>