<?php 
session_start();
require('../db.php');

 //$starting = $_POST['name'] ?? exit("Error: 'starting' field is missing!");


$name = $_POST['name'];
$special_price = $_POST['special_price'];
$price = $_POST['price'];
$price_category = $_POST['price_category'];
$color = $_POST['color'];
$size = $_POST['size'];


$image = '';


// upload image

if (isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $filename = $file['name'].rand(1111,9999);
    $tmpname = $file['tmp_name'];

    // Upload folder
    $folder = "../uploads/" . $filename;

    // Move image from temp to uploads folder
    if (move_uploaded_file($tmpname, $folder)) {
       $image = '/uploads/'.$filename;
    } else {
   
    }
}

////////////

if (!empty($_GET['id'])) {
  $id = $_GET['id'];
 $image = $image ? $image : ($_POST['old_image'] ?? '');

// update
  $sql = "UPDATE products SET name = '$name', special_price = '$special_price' , price= '$price', image = '$image' , price_category = '$price_category' , color = '$color' , size = '$size' WHERE id = '$id' ";
}else{
  // insert


  $sql = "INSERT INTO products(name,special_price,price,image,price_category,color,size)
   VALUES ('$name', '$special_price','$price','$image','$price_category','$color','$size')";
}

// echo $sql;exit;

 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ../product.php?=1');
} else {
   header('Location: ../add-product.php?error=1');
}


 ?>