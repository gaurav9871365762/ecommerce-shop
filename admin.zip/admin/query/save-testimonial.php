 <?php 
session_start();
require('../db.php');

require('./helper.php');


 //$starting = $_POST['name'] ?? exit("Error: 'starting' field is missing!");

$name = $_POST['name'];
$course = $_POST['course'];
$description = $_POST['description'];
$image = '';
$slug = slug($name);

// upload image

if (isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $filename = $file['name'].rand(1111,9999);
    $tmpname = $file['tmp_name'];

    // Upload folder
    $folder = "../uploads/" . $filename;

    // Move image from temp to uploads folder
    if (move_uploaded_file($tmpname, $folder)) {
       $image = '../uploads/'.$filename;
    } else {
   
    }
}

////////////

if (!empty($_GET['id'])) {
  $id = $_GET['id'];
 $image = $image?$image:$_POST['old_image'];

// update
  $sql = "UPDATE testimonial SET name = '$name', course = '$course' ,description='$description' , image = '$image',slug='$slug'  WHERE id = '$id' ";
}else{
  // insert
  $sql = "INSERT INTO testimonial(name,course,description,image,slug) VALUES ('$name', '$course','$description','$image','$slug')";
}



 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ../testimonial.php?=1');
} else {
   header('Location: ../add-testimonial.php?error=1');
}


 ?>