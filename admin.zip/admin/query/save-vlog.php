<?php 
session_start();
require('../db.php');

require('./helper.php');


$name = $_POST['name'];
$writer = $_POST['writer'];
$rating = $_POST['rating'];
$outof = $_POST['outof'];
$description = $_POST['description'];
 $slug = slug($name);

$image = '';


// upload image

if (isset($_FILES['image'])) {
    $file = $_FILES['image'];
    $filename = $file['name'].rand(1111,9999);
    $tmpname = $file['tmp_name'];

    // Upload folder
    $folder = "../uploads/" . $filename;

    // Move image from temp to uploads folder
    if (move_uploaded_file($tmpname, $folder)) {
       $image = '/uploads/'.$filename;
    } else {
   
    }
}

////////////

if (!empty($_GET['id'])) {
  $id = $_GET['id'];
  $image = $image?$image:$_POST['old_image'];
// update
  $sql = "UPDATE vlog SET name = '$name', writer = '$writer' , rating = '$rating',outof ='$outof',description ='$description', image = '$image' ,slug = '$slug' WHERE id = '$id' ";
}else{
  // insert
  $sql = "INSERT INTO vlog (name, writer, rating,image,outof,description,slug) VALUES ('$name', '$writer', '$rating','$image','$outof','$description','$slug')";;
}



 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ../vlog.php?success=1');
} else {
   header('Location: ../add-vlog.php?error=1');
}


 ?>