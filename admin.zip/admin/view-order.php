<?php include('db.php') ?>
<!DOCTYPE html>
<html>
<head>
    <title>View order</title>

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" type="text/css" href="view-css.css">

</head>
<body>

<style type="text/css">
    tr{
        border: 2px solid;
    }
</style>

<div>
    <div class="purchase overflow-auto">
        <!--<div style="min-width: 600px">-->


        <?php 
        $id = $_GET['id'];
        // get order detail by id


// Fetch all cart items
$sql = "SELECT ord.*, ur.name 
        FROM orders AS ord 
        LEFT JOIN users AS ur ON ord.user_id = ur.id 
        WHERE ord.id = '$id'";

$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $detail = mysqli_fetch_assoc($result);  // order detail
   $order_id = $detail['id']; 

// Fetch all cart items
$sql = "SELECT op.*,pd.name as product_name,pd.image,op.special_price,op.quantity FROM order_products as op LEFT JOIN products as pd on op.product_id=pd.id WHERE op.order_id='$order_id'";
$result = mysqli_query($conn, $sql);
$order_products = $result->fetch_all(MYSQLI_ASSOC);  // all orders products

// echo '<pre>';
// print_r($order_products); exit;

} else {
    echo "No order found.";
}


?>






            <header>
                <div class="row">
                    <div class="col-sm-3 col-xs-3">
                        <img src="./src/gr.jpeg" class="img-responsive">
                    </div>
                    <div class="col-sm-9 col-xs-9 company-details">
                        <h2><b>Shipping Address</b></h2>
                        <div><?php echo $detail['fname'].' '.$detail['lname'] ?></div>
                        <div><?php echo $detail['address1'].' '.$detail['address1'].' '.$detail['city'].' '.$detail['state'].' '.$detail['country']; ?></div>
                        <div><?php echo $detail['phone']; ?></div>
                       <div>Payment Mode: <?php echo $detail['payment']; ?></div>
                    </div>
                </div>
            </header>
            <main>
                <div class="row">
                    <div class="col-sm-3 col-xs-3 to-details">
                        <div>Invoice:</div>
                                           </div>
                    <div class="col-sm-9 col-xs-9 purchase-info">
                        <h4 class="info-code">ORDER ID: # <?php echo $detail['id']; ?></h4>


                        <div class="info-date">Issued :<?php echo $detail['create_date'] ?> </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12 col-xs-12 table-responsive">
                        <table class="table table-condensed" border="0" cellspacing="0" cellpadding="0" width="100%">
                        <thead>
                            <tr>
                                <th class="text-center col-xs-1 col-sm-1">#</th>
                                <th class="text-center col-xs-7 col-sm-7">Name</th>
                                 <th class="text-center col-xs-1 col-sm-1">Price</th>
                                <th class="text-center col-xs-1 col-sm-1">Qty</th>
                                <th class="text-center col-xs-3 col-sm-3">Amount</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php if (!empty($order_products)) {
                                    foreach ($order_products as $key => $value) {?>
                   
                            <tr>
                                <td class="col-xs-1 col-sm-1 text-center"><?php echo $key+1; ?></td>
                                <td class="text-center"><?php echo $value['product_name'] ?></td>
                                 <td class="text-center"><?php echo $value['special_price'] ?></td>
                                <td class="text-center"><?php echo $value['quantity'] ?></td>
                                <td class="text-right"><?php echo $value['total'] ?></td>
                            </tr>

                        <?php } } ?>
                            
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="2">
                                    Information<br>
                                    Information content
                                </th>                             
                                
                            </tr>

                             <tr>
                                <th colspan="3">                                  
                                </th>
                               
                                <th class="text-center">Sub Total</th>
                                <th class="text-right"><?php echo $detail['subtotal']; ?></th>
                            </tr>
                           <tr>
                                <th colspan="3">                                  
                                </th>
                               
                                <th class="text-center">Shipping</th>
                                <th class="text-right"> + <?php echo $detail['shiping']; ?></th>
                            </tr>

                             <tr>
                                <th colspan="3">                                  
                                </th>
                               
                                <th class="text-center">Discount</th>
                                <th class="text-right"> - <?php echo $detail['discount']; ?></th>
                            </tr>


                             <tr>
                                <th colspan="3">                             
                                </th>                               
                                <th class="text-center">Grand Total</th>
                                <th class="text-right"><?php echo $detail['total']; ?></th>
                            </tr>
                        </tfoot>
                    </table>
                    </div>
                </div>
            </main>
        <!--</div>-->
    </div>
</div>

<div class="text-center">
    <button id="print" onclick="window.print()">Print</button>
</div>



</body>
</html>