<?php 
include('db.php');
session_start();

if (!empty($_POST)) {
  
	$username = $_POST['username'];
	$password = md5($_POST['password']);

     $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
                       $query = mysqli_query($conn,$sql);
                       $user = mysqli_fetch_assoc($query);

                       if(!empty($user)){
                       		$_SESSION['userDetail'] = true;
                       		$_SESSION['id'] = $user['id'];

                       		header('Location:index.php');
                       }else{

                          header('Location:login.php?error=true');
                       }


                   }  





 ?>