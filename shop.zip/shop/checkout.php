<?php 
require('header.php');
require('db.php');

$user_id = $_SESSION['id'];


// Fetch all cart items
$sql = "SELECT ct.*,pd.name,pd.image,pd.price,pd.special_price FROM cart as ct LEFT JOIN products as pd on ct.product_id=pd.id WHERE ct.user_id= $user_id";
$result = mysqli_query($conn, $sql);
$cartItems = $result->fetch_all(MYSQLI_ASSOC);
    
// Initialize
$subtotal = 0;
$shipping = 0;

?>

<!-- Checkout Form -->
<form method="POST" action="save-checkout.php">
    <div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <div class="col-lg-8">
                <div class="mb-4">
                    <h4 class="font-weight-semi-bold mb-4">Billing Address</h4>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>First Name</label>
                            <input class="form-control" name="fname" type="text" placeholder="John" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Last Name</label>
                            <input class="form-control" name="lname" type="text" placeholder="Doe" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>E-mail</label>
                            <input class="form-control" name="email" type="email" placeholder="example@email.com" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Mobile No</label>
                            <input class="form-control" name="phone" type="text" placeholder="+91 1234567890" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Address Line 1</label>
                            <input class="form-control" name="address1" type="text" placeholder="123 Street" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Address Line 2</label>
                            <input class="form-control" name="address2" type="text" placeholder="Landmark or Area">
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Country</label>
                            <select class="custom-select" name="country" required>
                                <option value="India" selected>India</option>
                                <option>Afghanistan</option>
                                <option>Albania</option>
                                <option>Algeria</option>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>City</label>
                            <input class="form-control" name="city" type="text" placeholder="Delhi" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>State</label>
                            <input class="form-control" name="state" type="text" placeholder="Delhi" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>ZIP Code</label>
                            <input class="form-control" name="zip_code" type="text" placeholder="110001" required>
                        </div>
                    </div>
                </div>
            </div>
               


<!-- Order Total -->
<div class="col-lg-4">
    <div class="card border-secondary mb-5">
        <div class="card-header bg-secondary border-0">
            <h4 class="font-weight-semi-bold m-0">Order Total</h4>
        </div>
        <div class="card-body">
            <h5 class="font-weight-medium mb-3">Products</h5>

            <?php if (!empty($cartItems)) { ?>
                <?php foreach ($cartItems as $item) { $subtotal += $item['special_price']*$item['quantity']; ?>
                    <div class="d-flex justify-content-between">
                        <p><?= htmlspecialchars($item['name']) ?></p>
                        <p>Rs<?= $item['special_price']*$item['quantity']; ?></p>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class='alert alert-warning'>Your cart is empty.</div>
            <?php } ?>

            <hr class="mt-0">
            <div class="d-flex justify-content-between mb-3 pt-1">
                <h6 class="font-weight-medium">Subtotal</h6>
                <h6 class="font-weight-medium">Rs<?= number_format($subtotal, 2) ?></h6>
            </div>
            <div class="d-flex justify-content-between">
                <h6 class="font-weight-medium">Shipping</h6>
                <h6 class="font-weight-medium">Rs<?= number_format($subtotal*1/100, 2) ?></h6>
            </div>
        </div>
        <div class="card-footer border-secondary bg-transparent">
            <div class="d-flex justify-content-between mt-2">
                <h5 class="font-weight-bold">Total</h5>
                <h5 class="font-weight-bold">Rs<?= $subtotal+($subtotal*1/100) ?></h5>
            </div>
        </div>
    </div>
</div>

                <!-- Payment and Submit -->
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Payment</h4>
                    </div>
                    <div class="card-body">
                        <div class="custom-control custom-radio">
                            <input type="radio" class="custom-control-input" name="payment" id="paypal" value="paypal">
                            <label class="custom-control-label" for="paypal">Paypal</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" value="upi" class="custom-control-input" name="payment" id="directcheck">
                            <label class="custom-control-label" for="directcheck">Upi</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio"  value="cod" class="custom-control-input" name="payment" id="banktransfer">
                            <label class="custom-control-label" for="banktransfer">Cash on Delivery</label>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <button type="submit" class="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<?php include('footer.php'); ?>
