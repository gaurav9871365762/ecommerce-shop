 
<?php

define('CATALOG', 'asset/');
define('BASE_URL','http://localhost:8080/shop');
define('ADMIN_URL','http://localhost:8080/admin');


?>

