<?php
$servername = "localhost";
$email = "root";
$password = '';
$db = "shopdatabase";
// Create connection
$conn = new mysqli($servername, $email, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";
?>