<?php 
include('header.php');
require('db.php');

if (!empty($_SESSION['userDetail']) && $_SESSION['userDetail'] == true) {
   header('Location: index.php');
}
?>

<style>
    .login-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 80vh;
        background-color: #f5f5f5;
        padding: 40px 15px;
    }

    .login-card {
        background: #ffffff;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        padding: 30px;
        width: 100%;
        max-width: 400px;
    }

    .login-card h2 {
        font-weight: bold;
        margin-bottom: 25px;
        text-align: center;
        color: #343a40;
    }

    .btn-custom {
        background-color: #007bff;
        color: white;
        font-weight: bold;
        transition: 0.3s;
    }

    .btn-custom:hover {
        background-color: #0056b3;
    }
</style>

<div class="container login-wrapper">
    <div class="login-card">
        <h2>Login</h2>
        <form method="POST" action="auth.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" class="form-control" id="username" placeholder="Enter username" required>
            </div>
            <div class="form-group mt-3">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-custom btn-block mt-4">Login</button>
            <div class="mt-3 text-center">
                <small>Don't have an account? <a href="signup.php">Sign up</a></small>
            </div>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
