<?php 
session_start();
require('db.php');


$product_id = $_GET['product'];
$user_id = $_SESSION['id'];
$quantity = 1;

////////////
$sql = "SELECT * from cart where user_id=$user_id and product_id=$product_id";
$result = mysqli_query($conn,$sql);

$checkAlreadyExits = mysqli_fetch_assoc($result);

if (!empty($checkAlreadyExits)) {
  $id = $checkAlreadyExits['id'];
  
   $quantity  +=  $checkAlreadyExits['quantity']; 
   // update
   $sql = "UPDATE cart SET quantity = '$quantity' WHERE id = '$id' ";


}else{
  // insert

  $sql = "INSERT INTO cart(product_id,user_id,quantity)
   VALUES ('$product_id', '$user_id','$quantity')";
}

// echo $sql;exit;

 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: shop.php?=1');
} else {
   header('Location: shop.php?error=1');
}


 ?>