
<?php 
session_start();
require('db.php');

$result = false;
$user_id = $_SESSION['id'];
 if(!empty($_POST)){

	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];

	$address1 = $_POST['address1'];
	$address2 = $_POST['address2'];
	$country = $_POST['country'];
	$state = $_POST['state'];
	$city = $_POST['city'];
	$zip_code = $_POST['zip_code'];
	$payment = $_POST['payment'];


   $sql = "INSERT INTO orders(fname,lname,email,phone,address1,address2,country,city,state,zip_code,payment,user_id) VALUES ('$fname','$lname', '$email','$phone','$address1','$address2','$country','$city','$state','$zip_code','$payment','$user_id')";
	
   $result = mysqli_query($conn, $sql);


	 $order_id = mysqli_insert_id($conn);
	 $subtotal = 0;
	 $total = 0;
	 $shiping = 0;
	 $total_discount = 0;

 if(!empty($order_id)){

    $user_id = $_SESSION['id'];
	// Fetch all cart items
	$sql = "SELECT ct.*,pd.name,pd.image,pd.price,pd.special_price FROM cart as ct LEFT JOIN products as pd on ct.product_id=pd.id WHERE ct.user_id= $user_id";
	$result = mysqli_query($conn, $sql);
	$cartItems = $result->fetch_all(MYSQLI_ASSOC);
    
	if (!empty($cartItems)) { foreach ($cartItems as $key => $value) {
		// echo '<pre>';
		// print_r($value); exit;
		
		// insert cart product in order product table
        $product_total = $value['special_price']*$value['quantity'];
		$product_id = $value['product_id'];
		$quantity = $value['quantity'];
		$special_price = $value['special_price'];
        $discount = $value['special_price']*1/100;
 
       // this is for order table data
		 $subtotal += $value['special_price']*$value['quantity'];
		 $total_discount += $value['special_price']*1/100;
		 // end

		$sql = "INSERT INTO order_products(order_id,product_id,quantity,special_price,total,discount) VALUES ('$order_id','$product_id', '$quantity','$special_price','$product_total','$discount')";

       $result = mysqli_query($conn, $sql);

	  }

      // update order update for total price, shippint total , total discount

       $shiping = $subtotal*2/100; // fixed shipping 40;

       $grandTotal = ($subtotal+ $shiping) - $total_discount; 


       $sql = "UPDATE orders set subtotal ='$subtotal',discount ='$total_discount',shiping ='$shiping', total ='$grandTotal' WHERE id = '$order_id' ";
        $result = mysqli_query($conn, $sql);
     
     // clear cart 

        $sql  = "DELETE FROM cart WHERE user_id = '$user_id'";
          $result = mysqli_query($conn, $sql);
	}
		
 }
}
if ($result) {
   header('Location: cart.php?=1');
} else {
   header('Location:cart.php?error=1');
}


 ?>