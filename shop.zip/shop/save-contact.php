<?php 
session_start();
require('db.php');

if (!empty($_POST)) {

$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$massage = $_POST['massage'];

  // insert
  $sql = "INSERT INTO contact(name,email,subject,massage) VALUES ('$name', '$email','$subject','$massage')";

 $result = mysqli_query($conn, $sql);

if ($result) {
    echo true;
} else {
   echo false;
}
exit;

}
 ?>