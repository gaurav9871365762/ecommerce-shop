<?php 
session_start();
require('db.php');

 //$starting = $_POST['name'] ?? exit("Error: 'starting' field is missing!");







if (!empty($_POST)) {
 $name = $_POST['name'];
  $price = $_POST['price'];
$color = $_POST['color'];

$size = $_POST['size'];




// upload image


 $sql =  "INSERT INTO shop(name,price, color, size) 
        VALUES ('$name','$price' ,'$color', '$size')";

 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: shop.php?success=1');
} else {
   header('Location: index.php?error=1');
}

}
 ?>