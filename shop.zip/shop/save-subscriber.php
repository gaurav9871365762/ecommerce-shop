<?php 
session_start();
require('../db.php');

 

$name = $_POST['name'];
$email = $_POST['email'];


if (!empty($_GET['id'])) {
  $id = $_GET['id'];
 
  $sql = "UPDATE subscriber SET name = '$name', email = '$email'  WHERE id = '$id' ";
}else{
  // insert
  $sql = "INSERT INTO subscriber(name,email) VALUES ('$name', '$email')";
}



 $result = mysqli_query($conn, $sql);

if ($result) {
   header('Location: ..admin/subscribe.php?=1');
} else {
   header('Location: ..admin/add-subscribe.php?error=1');
}


 ?>