<?php include('header.php'); 
include 'db.php';


?>
<!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Our Shop</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Shop</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->
 <?php  


$priceId ='';
$sizeId ='';
$colorId ='';

        $sql = "SELECT pd.*,pr.name as price_category_name,sz.name as size_name, clr.name as color_name FROM products as pd  LEFT JOIN price as pr on pd.price_category=pr.id LEFT JOIN size as sz on pd.size=sz.id LEFT JOIN color as clr on pd.color=clr.id "        ;


if (!empty($_GET)) {
    $conditions = [];

    if (!empty($_GET['price'])) {
        $priceId = $_GET['price'];
        $priceId = implode(',', $priceId);
        if (!empty($priceId))
            $conditions[] = "pd.price_category IN($priceId)";
    }

    if (!empty($_GET['size'])) {
        $sizeId = $_GET['size'];
        $sizeId = implode(',', $sizeId);
        if (!empty($sizeId))
            $conditions[] = "pd.size IN($sizeId)";
    }

    if (!empty($_GET['color'])) {
        $colorId = $_GET['color'];
        $colorId = implode(',', $colorId);
        if (!empty($colorId))
            $conditions[] = "pd.color IN($colorId)";
    }

    if (!empty($conditions)) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
}

// echo $sql; exit;

$result = $conn->query($sql);
 $productlist = $result->fetch_all(MYSQLI_ASSOC);

?> 


    

    <!-- Shop Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <!-- Shop Sidebar Start -->

            
            <div class="col-lg-3 col-md-12">
                 <form action="shop.php" method="get">
                <!-- Price Start -->
                <div class="border-bottom mb-4 pb-4">
                    <h5 class="font-weight-semi-bold mb-4">Filter by price</h5>
                    

                     <?php  $sql = "SELECT * FROM price";
                        $result = $conn->query($sql);
                         $list = $result->fetch_all(MYSQLI_ASSOC);
                         if (!empty($list)) { 
                         foreach ($list as $key => $value){              
                      ?>
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox"  name="price[]" <?php echo in_array($value['id'], explode(',', $priceId)) ? 'checked' : ''; ?>
 value="<?php echo $value['id'] ?>" class="custom-control-input" id="price-<?php echo $value['id'] ?>">
                            <label class="custom-control-label" for="price-<?php echo $value['id'] ?>"><?php echo $value['name'] ?></label>
                            <span class="badge border font-weight-normal"><?php echo rand(111,222) ?></span>
                        </div>


                      

                    <?php }} ?>
                    
                </div>
                <!-- Price End -->
                
                <!-- Color Start -->
                <div class="border-bottom mb-4 pb-4">
                    <h5 class="font-weight-semi-bold mb-4">Filter by color</h5>
                   
                 <?php  $sql = "SELECT * FROM color";
                    $result = $conn->query($sql);
                     $list = $result->fetch_all(MYSQLI_ASSOC);
                     if (!empty($list)) { 
                     foreach ($list as $key => $value){              
                  ?>

                         <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox" name="color[]"<?php echo in_array($value['id'],explode(',', $colorId))? 'checked':''; ?> value="<?php echo $value['id'] ?>" class="custom-control-input" id="color-<?php echo $value['id'] ?>">
                            <label class="custom-control-label" for="color-<?php echo $value['id'] ?>"><?php echo $value['name'] ?></label>
                            <span class="badge border font-weight-normal"><?php echo rand(111,222) ?></span>
                        </div>



                    <?php }} ?>
                     
            
                </div>
                <!-- Color End -->

                <!-- Size Start -->
                <div class="mb-5">
                    <h5 class="font-weight-semi-bold mb-4">Filter by size</h5>
                  
                  <?php  $sql = "SELECT * FROM size";
                    $result = $conn->query($sql);
                     $list = $result->fetch_all(MYSQLI_ASSOC);
                     if (!empty($list)) { 
                     foreach ($list as $key => $value){              
                  ?>

                <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox" name="size[]"<?php echo in_array($value['id'],explode(',' , $sizeId))? 'checked':'';?> value="<?php echo $value['id'] ?>" class="custom-control-input" id="size-<?php echo $value['id'] ?>">
                            <label class="custom-control-label" for="size-<?php echo $value['id'] ?>"><?php echo $value['name'] ?></label>
                            <span class="badge border font-weight-normal"><?php echo rand(111,222) ?></span>
                        </div>

                    <?php }} ?>
                  
                    <button type="submit">submit</button>
                    
                </div>

                <!-- Size End -->
                   </form>
            </div>
          
            <!-- Shop Sidebar End -->


            <!-- Shop Product Start -->
            <div class="col-lg-9 col-md-12">
                <div class="row pb-3">
                    <div class="col-12 pb-1">
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <form action="">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search by name">
                                    <div class="input-group-append">
                                        <span class="input-group-text bg-transparent text-primary">
                                            <i class="fa fa-search"></i>
                                        </span>
                                    </div>
                                </div>
                            </form>
                            <div class="dropdown ml-4">
                                <button class="btn border dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="false">
                                            Sort by
                                        </button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                    <a class="dropdown-item" href="#">Latest</a>
                                    <a class="dropdown-item" href="#">Popularity</a>
                                    <a class="dropdown-item" href="#">Best Rating</a>
                                </div>
                            </div>
                        </div>
                    </div>
                  
  <?php 

         if (!empty($productlist)) { 
              foreach ($productlist as $key => $value) { ?>




                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="<?php echo ADMIN_URL.$value['image'];?>" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3"><?php echo $value['name'] ?></h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rs <?php echo $value['special_price'] ?></h6><h6 class="text-muted ml-2"><del>Rs <?php echo $value['price'] ?></del></h6>
                                </div>
                            </div>
                            <div class="card-footer d-flex justify-content-between bg-light border">
                                <a href="" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary mr-1"></i>View Detail</a>
                                <a href="save-cart.php?product=<?php echo $value['id']; ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                            </div>
                        </div>
                    </div>


                <?php }} ?>
               
                    
                    <div class="col-12 pb-1">
                        <nav aria-label="Page navigation">
                          <ul class="pagination justify-content-center mb-3">
                            <li class="page-item disabled">
                              <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                                <span class="sr-only">Previous</span>
                              </a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                              <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                                <span class="sr-only">Next</span>
                              </a>
                            </li>
                          </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- Shop Product End -->
        </div>
    </div>
    <!-- Shop End -->




<?php include('footer.php'); ?>