<?php

include('header.php');
require('db.php');

if (!empty($_SESSION['userDetail'])) {
   header('Location: index.php');
   exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['username'], $_POST['email'], $_POST['password'])) {
    $username = $_POST['username'];
    $email    = $_POST['email'];
    $password = md5($_POST['password']);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' OR email = '$email'");
    if (mysqli_num_rows($check) > 0) {
        $message = "<div class='alert alert-danger text-center'>Username ya Email already exists</div>";
    } else {
        $insert = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        if (mysqli_query($conn, $insert)) {
            $message = "<div class='alert alert-success text-center'>Registration successful! <a href='login.php'>Login Now</a></div>";
        } else {
            $message = "<div class='alert alert-danger text-center'>Error: " . mysqli_error($conn) . "</div>";
        }
    }
}
?>

<style>
.signup-container {
    background: #f8f9fa;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 8px 16px rgba(0,0,0,0.1);
}
.signup-container h2 {
    margin-bottom: 25px;
    font-weight: bold;
    color: #343a40;
}
.signup-container .form-control {
    border-radius: 12px;
}
.signup-container .btn-success {
    border-radius: 12px;
    padding: 10px 20px;
    font-weight: bold;
}
.signup-container p a {
    color: #007bff;
    text-decoration: none;
}
.signup-container p a:hover {
    text-decoration: underline;
}
</style>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="signup-container col-md-6">
        <h2 class="text-center">Create Your Account</h2>
        
        <?php if (!empty($message)) echo $message; ?>
        
        <form method="POST" action="signup.php">
            <div class="form-group mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username" required>
            </div>
            <div class="form-group mb-3">
                <label>Email address</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email" required>
            </div>
            <div class="form-group mb-4">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Sign Up</button>
            <p class="mt-3 text-center">Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
