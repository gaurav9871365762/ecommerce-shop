<?php 
session_start();
require('db.php');
$user_id = $_SESSION['id'];

if (!empty($_POST)) {

    $cartid = $_POST['cartid'];
   $type = $_POST['type'];

   $sql="SELECT * FROM cart where id=$cartid";
  $query = mysqli_query($conn,$sql);
  $detail = mysqli_fetch_assoc($query);

  $currentQty = $detail['quantity'];
  if($type=='minus'){
     if($currentQty==1){
        $sql ="DELETE from cart where id=$cartid";
     } else{
        $newQty = $currentQty-1;
        $sql ="UPDATE cart set quantity=$newQty where id=$cartid";
     }
     mysqli_query($conn,$sql);
    echo true; 
  }else{
    // plus
     $newQty = $currentQty+1;
     $sql ="UPDATE cart set quantity=$newQty where id=$cartid";
     mysqli_query($conn,$sql);
     echo true;

  }


}
?>